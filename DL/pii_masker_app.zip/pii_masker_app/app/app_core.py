import tkinter as tk
from tkinter import ttk, filedialog, messagebox
import pandas as pd
import os, json
from app.dict_utils import load_kana_dict, save_kana_dict, apply_kana_substitution
from app.mask_logic import MaskingHelpers
from app.ui_parts import apply_theme

try:
    from tkinterdnd2 import TkinterDnD, DND_FILES
    DND_AVAILABLE = True
except Exception:
    DND_AVAILABLE = False

USER_DICT_PATH = "data/user_dictionary.json"

COLUMN_OPTIONS = {
    "会社名": ["なし", "置換（仮名化）", "匿名（イニシャル）", "マスク処理（スペース以降）", "非表示"],
    "氏名": ["なし", "置換（仮名化）", "匿名（イニシャル）", "マスク処理（スペース以降）", "非表示"],
    "生年月日": ["なし", "マスク化（年代）", "非表示"],
    "性別": ["なし", "置換（女性→1,男性→2,その他→3）", "非表示"],
    "電話番号": ["なし", "マスク化（ハイフン以降）", "非表示"],
    "FAX番号": ["なし", "マスク化（ハイフン以降）", "非表示"],
    "メールアドレス": ["なし", "マスク化（頭3文字以外*）", "非表示"],
    "クレジット番号": ["なし", "マスク化（2桁目以降*）", "非表示"],
    "住所": ["なし", "マスク化（県以降*）", "非表示"],
    "注文金額": ["なし", "マスク化（上2桁以外切捨て）", "非表示"],
}
GENERIC_OPTIONS = ["なし", "マスク化（*置換）", "非表示"]


class PiiMaskerApp(MaskingHelpers):
    def __init__(self, root):
        self.root = root
        self.root.title("PII マスキングツール")
        self.root.geometry("1200x760")
        self.root.minsize(900, 600)

        self.df_original = None
        self.df_preview = None
        self.mask_settings = {}
        self.kana_dict = load_kana_dict()
        self.dark_mode = False
        self.mask_rows = {}
        self.name_mode_vars = {}

        os.makedirs("data", exist_ok=True)
        self._load_user_dictionary()

        self._create_ui()
        self._apply_theme()

        if DND_AVAILABLE:
            try:
                self.root.drop_target_register(DND_FILES)
                self.root.dnd_bind("<<Drop>>", self._on_drop)
            except Exception:
                pass

    # ---------------------
    # UI構築
    # ---------------------
    def _create_ui(self):
        menubar = tk.Menu(self.root)

        file_menu = tk.Menu(menubar, tearoff=0)
        file_menu.add_command(label="開く", command=self._read_file_wrapper)
        file_menu.add_command(label="名前をつけて保存(新規)", command=self._save_file)
        file_menu.add_separator()
        file_menu.add_command(label="終了", command=self.root.quit)
        menubar.add_cascade(label="ファイル", menu=file_menu)

        view_menu = tk.Menu(menubar, tearoff=0)
        view_menu.add_command(label="ライトモード", command=lambda: self._set_theme(False))
        view_menu.add_command(label="ダークモード", command=lambda: self._set_theme(True))
        menubar.add_cascade(label="表示", menu=view_menu)

        tools_menu = tk.Menu(menubar, tearoff=0)
        tools_menu.add_command(label="仮名化辞書の管理", command=self._open_dict_editor)
        menubar.add_cascade(label="ツール", menu=tools_menu)

        self.root.config(menu=menubar)

        top = ttk.Frame(self.root, padding=(8, 6))
        top.pack(fill="x")
        ttk.Button(top, text="ファイルを開く", command=self._read_file_wrapper).pack(side="left", padx=4)
        ttk.Button(top, text="名前をつけて保存(新規)", command=self._save_file).pack(side="left", padx=4)
        ttk.Button(top, text="リセット", command=self._confirm_reset).pack(side="left", padx=4)
        self.dnd_label = ttk.Label(
            top, text="Drag & Drop: 有効" if DND_AVAILABLE else "Drag & Drop: 無効 (tkinterdnd2未導入)"
        )
        self.dnd_label.pack(side="right")

        self.mask_frame = ttk.LabelFrame(self.root, text="マスキング方式設定")
        self.mask_frame.pack(fill="x", padx=10, pady=(6, 4))

        frame = ttk.Frame(self.root)
        frame.pack(fill="both", expand=True, padx=10, pady=6)
        self.tree = ttk.Treeview(frame, show="headings")
        vbar = ttk.Scrollbar(frame, orient="vertical", command=self.tree.yview)
        hbar = ttk.Scrollbar(frame, orient="horizontal", command=self.tree.xview)
        self.tree.configure(yscrollcommand=vbar.set, xscrollcommand=hbar.set)
        self.tree.grid(row=0, column=0, sticky="nsew")
        vbar.grid(row=0, column=1, sticky="ns")
        hbar.grid(row=1, column=0, sticky="ew")
        frame.rowconfigure(0, weight=1)
        frame.columnconfigure(0, weight=1)

        self.status = ttk.Label(self.root, text="Ready", anchor="w")
        self.status.pack(fill="x", padx=6, pady=(0, 6))

    # ---------------------
    # テーマ
    # ---------------------
    def _set_theme(self, dark: bool):
        self.dark_mode = bool(dark)
        self._apply_theme()

    def _apply_theme(self):
        apply_theme(self.root, self.dark_mode, self.mask_frame, self.status, self.mask_rows, self.tree)

    # ---------------------
    # ファイル操作
    # ---------------------
    def _read_file_wrapper(self):
        path = filedialog.askopenfilename(filetypes=[("Excel/CSV", "*.xlsx *.xls *.csv"), ("All", "*.*")])
        if path:
            self._read_file(path)

    def _on_drop(self, event):
        data = event.data
        if not data:
            return
        files = []
        cur = ""
        in_brace = False
        for ch in data:
            if ch == "{":
                in_brace = True
                cur = ""
            elif ch == "}":
                in_brace = False
                files.append(cur)
            elif in_brace:
                cur += ch
            elif ch == " ":
                continue
            else:
                cur += ch
        if not files:
            files = [data]
        first = files[0]
        if os.path.exists(first):
            self._read_file(first)
        else:
            messagebox.showerror("読み込みエラー", f"ファイルが見つかりません:\n{first}")

    def _read_file(self, path):
        try:
            ext = os.path.splitext(path)[1].lower()
            if ext in (".xlsx", ".xls"):
                df = pd.read_excel(path, dtype=str)
            elif ext == ".csv":
                for enc in ("utf-8", "shift_jis", "latin1"):
                    try:
                        df = pd.read_csv(path, dtype=str, encoding=enc)
                        break
                    except Exception:
                        continue
            else:
                messagebox.showerror("エラー", "対応していないファイル形式です。")
                return
            self.df_original = df.fillna("")
            self.file_path = path
            self._update_mask_controls()
            self._update_preview()
            self.status.config(text=f"読み込み完了: {os.path.basename(path)} ({len(df)} 行)")
        except Exception as e:
            messagebox.showerror("読み込みエラー", str(e))

    # ---------------------
    # マスク設定 UI
    # ---------------------
    def _update_mask_controls(self):
        for w in self.mask_frame.winfo_children():
            w.destroy()
        self.mask_rows.clear()
        if self.df_original is None:
            return

        for col in self.df_original.columns:
            opts = COLUMN_OPTIONS.get(col, GENERIC_OPTIONS)
            row_frame = ttk.Frame(self.mask_frame)
            row_frame.pack(fill="x", padx=6, pady=3)
            lbl = ttk.Label(row_frame, text=col, width=24, anchor="w")
            lbl.pack(side="left")
            cmb = ttk.Combobox(row_frame, values=opts, state="readonly", width=36)
            cmb.set(self.mask_settings.get(col, "なし"))
            cmb.pack(side="left", padx=(6, 10))
            cmb.bind("<<ComboboxSelected>>", lambda e, c=col, cb=cmb: self._on_mask_option_changed(c, cb.get()))
            self.mask_rows[col] = (row_frame, lbl, cmb)

    def _on_mask_option_changed(self, col, option):
        self.mask_settings[col] = option
        self._update_preview()

    # ---------------------
    # プレビュー更新
    # ---------------------
    def _update_preview(self):
        if self.df_original is None:
            return
        df = self.df_original.copy()
        for col in df.columns:
            opt = self.mask_settings.get(col, "なし")
            if opt == "なし":
                continue
            if opt.startswith("置換（仮名化") and col in ("氏名", "会社名"):
                df[col] = df[col].astype(str).apply(lambda v: apply_kana_substitution(v, col, self.kana_dict))
            elif opt.startswith("匿名（イニシャル"):
                df[col] = df[col].astype(str).apply(lambda v: self._to_initial(v))
            elif opt.startswith("マスク化") or opt.startswith("マスク処理"):
                if col in ("電話番号", "FAX番号"):
                    df[col] = df[col].astype(str).apply(self._mask_after_hyphen)
                elif col == "メールアドレス":
                    df[col] = df[col].astype(str).apply(self._mask_email_localpart)
                elif col == "住所":
                    df[col] = df[col].astype(str).apply(self._mask_address)
                elif col == "注文金額":
                    df[col] = df[col].astype(str).apply(self._truncate_order_amount)
                elif col == "生年月日":
                    df[col] = df[col].astype(str).apply(self._birth_to_decade)
            elif opt.startswith("置換（女性"):
                df[col] = df[col].astype(str).apply(self._map_gender)
            elif opt.startswith("非表示"):
                df[col] = ""

        self.df_preview = df
        self._refresh_tree(df)

    def _refresh_tree(self, df):
        self.tree.delete(*self.tree.get_children())
        self.tree["columns"] = list(df.columns)
        for c in df.columns:
            self.tree.heading(c, text=c)
            self.tree.column(c, width=120, anchor="w", stretch=True)
        for idx, row in df.iterrows():
            self.tree.insert("", "end", values=list(row))

    # ---------------------
    # 仮名化辞書エディタ（改良版）
    # ---------------------
    def _open_dict_editor(self):
        editor = tk.Toplevel(self.root)
        editor.title("仮名化辞書の管理")
        editor.geometry("780x560")

        frame_top = ttk.Frame(editor)
        frame_top.pack(fill="x", pady=8, padx=10)

        ttk.Label(frame_top, text="検索:", width=6).pack(side="left")
        search_var = tk.StringVar()
        search_entry = ttk.Entry(frame_top, textvariable=search_var, width=40)
        search_entry.pack(side="left", padx=4)
        ttk.Button(frame_top, text="クリア", command=lambda: (search_var.set(""), refresh_tree())).pack(side="left", padx=6)

        tree = ttk.Treeview(editor, columns=("original", "pseudo"), show="headings", height=18)
        tree.heading("original", text="元の値（氏名・会社名など）")
        tree.heading("pseudo", text="置換後の値（仮名）")
        tree.column("original", width=300)
        tree.column("pseudo", width=300)
        tree.pack(fill="both", expand=True, padx=10, pady=(0,8))

        vbar = ttk.Scrollbar(tree, orient="vertical", command=tree.yview)
        tree.configure(yscrollcommand=vbar.set)
        vbar.pack(side="right", fill="y")

        frame_bottom = ttk.LabelFrame(editor, text="新規登録 / 編集", padding=10)
        frame_bottom.pack(fill="x", padx=10, pady=6)

        ttk.Label(frame_bottom, text="元の値:").grid(row=0, column=0, padx=6, pady=6, sticky="e")
        ttk.Label(frame_bottom, text="置換後の値:").grid(row=1, column=0, padx=6, pady=6, sticky="e")

        key_var = tk.StringVar()
        val_var = tk.StringVar()
        key_entry = ttk.Entry(frame_bottom, textvariable=key_var, width=50)
        val_entry = ttk.Entry(frame_bottom, textvariable=val_var, width=50)
        key_entry.grid(row=0, column=1, padx=6, pady=6, sticky="w")
        val_entry.grid(row=1, column=1, padx=6, pady=6, sticky="w")

        status_label = ttk.Label(editor, text="辞書件数: 0", anchor="w")
        status_label.pack(fill="x", padx=10, pady=(0,4))

        def refresh_tree(filter_text=""):
            tree.delete(*tree.get_children())
            count = 0
            for k, v in sorted(self.kana_dict.items()):
                if not filter_text or filter_text.lower() in k.lower() or filter_text.lower() in v.lower():
                    tree.insert("", "end", values=(k, v))
                    count += 1
            status_label.config(text=f"辞書件数: {len(self.kana_dict)}（表示中 {count} 件）")

        def on_search(*args):
            refresh_tree(search_var.get().strip())

        search_var.trace_add("write", lambda *a: on_search())

        def on_select(event):
            selected = tree.selection()
            if not selected:
                return
            item = tree.item(selected[0], "values")
            key_var.set(item[0])
            val_var.set(item[1])

        tree.bind("<<TreeviewSelect>>", on_select)

        def on_double_click(event):
            on_select(event)
            key_entry.focus()

        tree.bind("<Double-1>", on_double_click)

        def add_or_update():
            key = key_var.get().strip()
            val = val_var.get().strip()
            if not key or not val:
                messagebox.showwarning("入力エラー", "元の値と置換後の値を両方入力してください。")
                return
            if key in self.kana_dict:
                msg = f"『{key}』を更新しました。"
            else:
                msg = f"『{key}』を追加しました。"
            self.kana_dict[key] = val
            refresh_tree(search_var.get().strip())
            key_var.set("")
            val_var.set("")
            status_label.config(text=msg)

        def delete_selected():
            selected = tree.selection()
            if not selected:
                messagebox.showinfo("情報", "削除する項目を選択してください。")
                return
            key = tree.item(selected[0], "values")[0]
            if messagebox.askyesno("確認", f"『{key}』を削除しますか？"):
                self.kana_dict.pop(key, None)
                refresh_tree(search_var.get().strip())
                status_label.config(text=f"『{key}』を削除しました。")

        def delete_all():
            if messagebox.askyesno("確認", "全項目を削除しますか？（元に戻せません）"):
                self.kana_dict.clear()
                refresh_tree()
                status_label.config(text="すべて削除しました。")

        def save_dict():
            try:
                save_kana_dict(self.kana_dict)
                messagebox.showinfo("完了", "仮名化辞書を保存しました。")
                self._update_preview()
                editor.destroy()
            except Exception as e:
                messagebox.showerror("保存エラー", str(e))

        btn_frame = ttk.Frame(editor)
        btn_frame.pack(fill="x", pady=6)

        ttk.Button(btn_frame, text="追加 / 更新 (Enter)", command=add_or_update).pack(side="left", padx=6)
        ttk.Button(btn_frame, text="削除", command=delete_selected).pack(side="left", padx=6)
        ttk.Button(btn_frame, text="全削除", command=delete_all).pack(side="left", padx=6)
        ttk.Button(btn_frame, text="💾 保存して閉じる", command=save_dict).pack(side="right", padx=6)

        val_entry.bind("<Return>", lambda e: add_or_update())
        key_entry.bind("<Return>", lambda e: add_or_update())

        refresh_tree()

    # ---------------------
    # 保存・リセット・ユーザー辞書
    # ---------------------
    def _save_file(self):
        if self.df_preview is None:
            messagebox.showwarning("警告", "保存するプレビューがありません。")
            return
        save_path = filedialog.asksaveasfilename(defaultextension=".xlsx", filetypes=[("Excel", "*.xlsx")])
        if save_path:
            self.df_preview.to_excel(save_path, index=False)
            self.status.config(text=f"保存完了: {save_path}")

    def _confirm_reset(self):
        if messagebox.askyesno("確認", "設定とプレビューをリセットしますか？"):
            self.mask_settings.clear()
            self.df_preview = None
            self._update_mask_controls()
            # clear tree
            try:
                import pandas as _pd
                self._refresh_tree(_pd.DataFrame())
            except Exception:
                self.tree.delete(*self.tree.get_children())
            self.status.config(text="リセット完了")

    def _load_user_dictionary(self):
        if os.path.exists(USER_DICT_PATH):
            with open(USER_DICT_PATH, "r", encoding="utf-8") as f:
                try:
                    self.user_dict = json.load(f)
                except Exception:
                    self.user_dict = {}
        else:
            self.user_dict = {}

def main():
    if DND_AVAILABLE:
        root = TkinterDnD.Tk()
    else:
        root = tk.Tk()
    app = PiiMaskerApp(root)
    root.mainloop()


if __name__ == "__main__":
    main()

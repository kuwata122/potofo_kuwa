import os
import json
import random

DATA_DIR = "data"
KANA_DICT_PATH = os.path.join(DATA_DIR, "kana_dict.json")


def load_kana_dict():
    """
    優先順:
    1) data/kana_dict.json があればそれを読み込む
    2) カレントディレクトリに kana_dict.json があれば読み込み、data/ にコピーして読み込む
    3) なければ空辞書を返す
    """
    # ensure data dir exists for potential save later
    os.makedirs(DATA_DIR, exist_ok=True)

    if os.path.exists(KANA_DICT_PATH):
        try:
            with open(KANA_DICT_PATH, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            return {}
    # fallback: check for kana_dict.json in current directory (uploaded file might be here)
    alt = "kana_dict.json"
    if os.path.exists(alt):
        try:
            with open(alt, "r", encoding="utf-8") as f:
                data = json.load(f)
            # save into data/
            with open(KANA_DICT_PATH, "w", encoding="utf-8") as fw:
                json.dump(data, fw, ensure_ascii=False, indent=2)
            return data
        except Exception:
            return {}
    return {}


def save_kana_dict(kana_dict):
    os.makedirs(DATA_DIR, exist_ok=True)
    with open(KANA_DICT_PATH, "w", encoding="utf-8") as f:
        json.dump(kana_dict, f, ensure_ascii=False, indent=2)


def generate_pseudo_name():
    first_names = ["佐藤", "鈴木", "高橋", "田中", "渡辺", "伊藤", "中村"]
    last_names = ["太郎", "花子", "陽介", "真央", "智也", "美咲", "翔", "紗季"]
    return random.choice(first_names) + random.choice(last_names)


def generate_pseudo_company():
    prefixes = ["カイセイ", "トウシン", "ミライ", "セントラル", "アクティブ", "ネオ"]
    suffixes = ["テック", "ソリューションズ", "ワークス", "システムズ", "コーポレーション"]
    return "株式会社" + random.choice(prefixes) + random.choice(suffixes)


def apply_kana_substitution(value, column_name, kana_dict):
    """
    元のロジックは変更しないでそのまま保持。
    見つからなければ自動生成し、辞書に保存する。
    """
    if column_name == "氏名":
        generator = generate_pseudo_name
    elif column_name == "会社名":
        generator = generate_pseudo_company
    else:
        return value  # 適用外

    if value in kana_dict:
        return kana_dict[value]
    else:
        pseudo = generator()
        kana_dict[value] = pseudo
        save_kana_dict(kana_dict)
        return pseudo

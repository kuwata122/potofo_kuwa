import re
import pandas as pd


class MaskingHelpers:
    """個人情報マスキング用の補助関数群"""

    # --- 氏名 ---
    def _to_initial(self, name: str) -> str:
        if not name:
            return ""
        parts = re.split(r"[ 　]", name)
        initials = [p[0] + "*" * (len(p) - 1) for p in parts if p]
        return " ".join(initials)

    # --- 電話番号 ---
    def _mask_after_hyphen(self, number: str) -> str:
        """
        電話番号の最初のハイフン以降をすべて * に置き換える。
        例: 090-1234-5678 → 090-****-****
        """
        if not number or "-" not in number:
            return number

        # 最初のハイフンで分割
        first, rest = number.split("-", 1)
        # 残り部分の数字を全てマスク（ハイフンは維持）
        masked_rest = re.sub(r"\d", "*", rest)
        return f"{first}-{masked_rest}"

    # --- メール ---
    def _mask_email_localpart(self, email: str) -> str:
        if "@" not in email:
            return email
        local, domain = email.split("@", 1)
        if len(local) <= 3:
            masked_local = "*" * len(local)
        else:
            masked_local = local[:3] + "*" * (len(local) - 3)
        return f"{masked_local}@{domain}"

    # --- 住所 ---
    def _mask_address(self, address: str) -> str:
        """
        都道府県名は残し、それ以降を * でマスクする。
        """
        if not address:
            return ""
        # 都道府県名（例: 東京都, 大阪府, 北海道, ○○県）までを抽出
        m = re.match(r"^(.*?[都道府県])", address)
        if not m:
            return "*" * len(address)
        pref = m.group(1)
        rest = address[len(pref):]
        return pref + ("*" * len(rest))

    # --- 生年月日 ---
    def _birth_to_decade(self, birth: str) -> str:
        """
        年代（◯◯代）に変換する。例: 1992-03-10 → 1990代
        """
        if not birth:
            return ""
        year_match = re.search(r"\d{4}", birth)
        if not year_match:
            return ""
        year = int(year_match.group())
        decade = (year // 10) * 10
        return f"{decade}代"

    # --- 性別 ---
    def _map_gender(self, gender: str) -> str:
        mapping = {"男性": "2", "女性": "1", "その他": "3"}
        return mapping.get(gender, gender)

    # --- 金額 ---
    def _truncate_order_amount(self, val: str) -> str:
        digits = re.sub(r"\D", "", val)
        if not digits:
            return val
        if len(digits) <= 2:
            return "0"
        return digits[:2] + "00"


import tkinter as tk
from tkinter import ttk

def apply_theme(root, dark_mode, mask_frame, status, mask_rows, tree):
    if dark_mode:
        bg = "#1e1e1e"; fg = "#eef0f1"; entry_bg = "#2b2b2b"
    else:
        bg = "#ffffff"; fg = "#111111"; entry_bg = "#ffffff"
    style = ttk.Style()
    try:
        style.theme_use("clam")
    except Exception:
        pass
    style.configure(".", background=bg, foreground=fg)
    style.configure("TLabel", background=bg, foreground=fg)
    style.configure("TFrame", background=bg)
    style.configure("TButton", background=entry_bg, foreground=fg)
    style.configure("TCombobox", fieldbackground=entry_bg, background=entry_bg, foreground=fg)
    style.configure("Treeview", background=entry_bg, foreground=fg, fieldbackground=entry_bg)
    style.configure("Treeview.Heading", background=entry_bg, foreground=fg)
    try: root.configure(bg=bg)
    except Exception: pass
    widgets = [mask_frame, status]
    for w in widgets:
        try: w.configure(background=bg)
        except Exception: pass
    for col, row in mask_rows.items():
        frame = row[0]
        try: frame.configure(style="TFrame")
        except Exception: pass
    try: tree.tag_configure("oddrow", background=entry_bg)
    except Exception: pass

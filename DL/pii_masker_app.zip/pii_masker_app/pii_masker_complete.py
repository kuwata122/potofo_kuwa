from app.app_core import main

if __name__ == "__main__":
    main()
